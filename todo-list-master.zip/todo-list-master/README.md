# TodoList

A simple todo list in angular

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 7.3.9.

## Run the application

Launch the server with th command
> ng serve

and open your browser on *http://localhost:4200/*
